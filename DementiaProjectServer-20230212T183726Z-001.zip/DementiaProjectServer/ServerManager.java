import java.net.ServerSocket;

public class ServerManager extends Thread{
   /*  ServerSocket serverSocket = new ServerSocket(1234);
    while(true)
        new Main();
        */
    
}